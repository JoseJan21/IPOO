<?php

// include_once("Categoria.php");
// include_once("Torneo.php");
// include_once("Equipo.php");
// include_once("Partido.php");
// include_once("Fotbool.php");
// include_once("Basket.php");

// $catMayores = neW Categoria(1,'Mayores');
// $catJuveniles = neW Categoria(2,'juveniles');
// $catMenores = neW Categoria(1,'Menores');

// $objE1 = neW Equipo("Equipo Uno", "Cap.Uno",1,$catMayores);
// $objE2 = neW Equipo("Equipo Dos", "Cap.Dos",2,$catMayores);

// $objE3 = neW Equipo("Equipo Tres", "Cap.Tres",3,$catJuveniles);
// $objE4 = neW Equipo("Equipo Cuatro", "Cap.Cuatro",4,$catJuveniles);

// $objE5 = neW Equipo("Equipo Cinco", "Cap.Cinco",5,$catMayores);
// $objE6 = neW Equipo("Equipo Seis", "Cap.Seis",6,$catMayores);

// $objE7 = neW Equipo("Equipo Siete", "Cap.Siete",7,$catJuveniles);
// $objE8 = neW Equipo("Equipo Ocho", "Cap.Ocho",8,$catJuveniles);

// $objE9 = neW Equipo("Equipo Nueve", "Cap.Nueve",9,$catMenores);
// $objE10 = neW Equipo("Equipo Diez", "Cap.Diez",9,$catMenores);

// $objE11 = neW Equipo("Equipo Once", "Cap.Once",11,$catMayores);
// $objE12 = neW Equipo("Equipo Doce", "Cap.Doce",11,$catMayores);

// 

include_once("Categoria.php");
include_once("Torneo.php");
include_once("Equipo.php");
include_once("Partido.php");
include_once("PartidoFutbol.php");
include_once("PartidoBasquetbol.php");

$catMayores = new Categoria(1, 'Mayores');
$catJuveniles = new Categoria(2, 'Juveniles');
$catMenores = new Categoria(3, 'Menores');

$objE1 = new Equipo("Equipo Uno", "Cap.Uno", 1, $catMayores);
$objE2 = new Equipo("Equipo Dos", "Cap.Dos", 2, $catMayores);

$objE3 = new Equipo("Equipo Tres", "Cap.Tres", 3, $catJuveniles);
$objE4 = new Equipo("Equipo Cuatro", "Cap.Cuatro", 4, $catJuveniles);

$objE5 = new Equipo("Equipo Cinco", "Cap.Cinco", 5, $catMenores);
$objE6 = new Equipo("Equipo Seis", "Cap.Seis", 6, $catMenores);

$objE7 = new Equipo("Equipo Siete", "Cap.Siete", 7, $catMayores);
$objE8 = new Equipo("Equipo Ocho", "Cap.Ocho", 8, $catMayores);

$objE9 = new Equipo("Equipo Nueve", "Cap.Nueve", 9, $catJuveniles);
$objE10 = new Equipo("Equipo Diez", "Cap.Diez", 9, $catJuveniles);

$objE11 = new Equipo("Equipo Once", "Cap.Once", 11, $catMenores);
$objE12 = new Equipo("Equipo Doce", "Cap.Doce", 11, $catMenores);

// Crear un objeto de la clase Torneo con un importe base del premio de 100.000
$torneo = new Torneo(100000);

// Crear 3 objetos partidos de Básquet
$partidoBasquet1 = $torneo->ingresarPartido($objE7, $objE8, '2023-05-05', 'Basquetbol');
$partidoBasquet2 = $torneo->ingresarPartido($objE9, $objE10, '2024-05-06', 'Basquetbol');
$partidoBasquet3 = $torneo->ingresarPartido($objE11, $objE12, '2024-05-07', 'Basquetbol');

// Crear 3 objetos partidos de Fútbol
$partidoFutbol1 = $torneo->ingresarPartido($objE1, $objE2, '2024-05-07', 'Futbol');
$partidoFutbol2 = $torneo->ingresarPartido($objE3, $objE4, '2024-05-08', 'Futbol');
$partidoFutbol3 = $torneo->ingresarPartido($objE5, $objE6, '2024-05-09', 'Futbol');

// Ingresar un partido de fútbol y visualizar la respuesta y la cantidad de equipos del torneo.
try {
    $respuesta1 = $torneo->ingresarPartido($objE5, $objE11, '2024-05-23', 'Futbol');
    echo "Respuesta 1: ";
    print_r($respuesta1);
    echo "Cantidad de equipos del torneo: " . count($torneo->obtenerPartidos()) . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

// Ingresar un partido de básquetbol y visualizar la respuesta y la cantidad de equipos del torneo.
try {
    $respuesta2 = $torneo->ingresarPartido($objE11, $objE11, '2024-05-23', 'Basquetbol');
    echo "Respuesta 2: ";
    print_r($respuesta2);
    echo "Cantidad de equipos del torneo: " . count($torneo->obtenerPartidos()) . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

// Ingresar un partido de básquetbol y visualizar la respuesta y la cantidad de equipos del torneo.
try {
    $respuesta3 = $torneo->ingresarPartido($objE9, $objE10, '2024-05-25', 'Basquetbol');
    echo "Respuesta 3: ";
    print_r($respuesta3);
    echo "Cantidad de equipos del torneo: " . count($torneo->obtenerPartidos()) . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

// Obtener los ganadores de partidos de básquetbol y visualizar el resultado.
echo "Ganadores de partidos de básquetbol: ";
print_r($torneo->darGanadores('Basquetbol'));
echo "\n";

// Obtener los ganadores de partidos de fútbol y visualizar el resultado.
echo "Ganadores de partidos de fútbol: ";
print_r($torneo->darGanadores('Futbol'));
echo "\n";

// Calcular el premio para cada partido
echo "Premios de los partidos:\n";
$partidos = $torneo->obtenerPartidos();
foreach ($partidos as $partido) {
    $premio = $torneo->calcularPremioPartido($partido);
    echo "Partido ID: " . $partido->getIdpartido() . ", Premio: $" . $premio['premioPartido'] . "\n";
}

// Mostrar el objeto Torneo creado
echo "Objeto Torneo: \n";
print_r($torneo);

