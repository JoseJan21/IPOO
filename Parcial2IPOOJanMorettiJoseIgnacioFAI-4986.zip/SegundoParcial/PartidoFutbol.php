<?php

class PartidoFutbol extends Partido {
    private $categoria;
    private $coefMenores = 0.13;
    private $coefJuveniles = 0.19;
    private $coefMayores = 0.27;

    public function __construct($idpartido, $fecha, $objEquipo1, $cantGolesE1, $objEquipo2, $cantGolesE2, $categoria) {
        parent::__construct($idpartido, $fecha, $objEquipo1, $cantGolesE1, $objEquipo2, $cantGolesE2);
        $this->categoria = $categoria;
    }

    public function coeficientePartido() {
        $coef = parent::coeficientePartido();
        switch ($this->categoria) {
            case 'Menores':
                return $coef * $this->coefMenores;
            case 'Juveniles':
                return $coef * $this->coefJuveniles;
            case 'Mayores':
                return $coef * $this->coefMayores;
            default:
                throw new Exception("Categoría desconocida");
        }
    }
}