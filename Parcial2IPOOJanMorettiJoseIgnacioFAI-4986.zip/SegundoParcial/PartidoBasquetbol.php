<?php

class PartidoBasquetbol extends Partido {
    private $cantInfracciones;
    private $coefPenalizacion = 0.75;

    public function __construct($idpartido, $fecha, $objEquipo1, $cantGolesE1, $objEquipo2, $cantGolesE2, $cantInfracciones) {
        parent::__construct($idpartido, $fecha, $objEquipo1, $cantGolesE1, $objEquipo2, $cantGolesE2);
        $this->cantInfracciones = $cantInfracciones;
    }

    public function coeficientePartido() {
        $coef = parent::coeficientePartido();
        return $coef - ($this->coefPenalizacion * $this->cantInfracciones);
    }
}