<?php

class Torneo {
    private $partidos;
    private $importePremio;

    public function __construct($importePremio) {
        $this->partidos = [];
        $this->importePremio = $importePremio;
    }

    public function agregarPartido($partido) {
        $this->partidos[] = $partido;
    }

    public function obtenerPartidos() {
        return $this->partidos;
    }

    public function entregarPremios() {
        foreach ($this->partidos as $partido) {
            $coeficiente = $partido->coeficientePartido();
            $premio = $coeficiente * $this->importePremio;
            echo "Premio para el partido (ID: " . $partido->getIdpartido() . "): " . $premio . "\n";
        }
    }
    
    public function ingresarPartido($OBJEquipo1, $OBJEquipo2, $fecha, $tipoPartido) {
        $categoria1 = $OBJEquipo1->getObjCategoria()->getDescripcion();
        $categoria2 = $OBJEquipo2->getObjCategoria()->getDescripcion();
        $jugadores1 = $OBJEquipo1->getCantJugadores();
        $jugadores2 = $OBJEquipo2->getCantJugadores();

        if ($categoria1 === $categoria2 && abs($jugadores1 - $jugadores2) <= 1) {
    
            $idpartido = count($this->partidos) + 1;
            $cantGolesE1 = 0; // Inicialmente 0 goles
            $cantGolesE2 = 0; // Inicialmente 0 goles
    
            if ($tipoPartido === 'Futbol') {
                $partido = new PartidoFutbol($idpartido, $fecha, $OBJEquipo1, $cantGolesE1, $OBJEquipo2, $cantGolesE2, $OBJEquipo1->getObjCategoria()->getDescripcion());
            } elseif ($tipoPartido === 'Basquetbol') {
                $cantInfracciones = 0; // Inicialmente 0 infracciones
                $partido = new PartidoBasquetbol($idpartido, $fecha, $OBJEquipo1, $cantGolesE1, $OBJEquipo2, $cantGolesE2, $cantInfracciones);
            } else {
                throw new Exception("Tipo de partido desconocido");
            }
    
            $this->agregarPartido($partido);
            return $partido;
        } else {
            echo "Advertencia: Los equipos no cumplen con las condiciones para este partido.\n";
        }
    }
    public function darGanadores($deporte) {
        $ganadores = [];

        foreach ($this->partidos as $partido) {
            if ($deporte === 'Futbol' && $partido instanceof PartidoFutbol) {
                $ganador = $partido->darEquipoGanador();
                if (!in_array($ganador, $ganadores)) {
                    $ganadores[] = $ganador;
                }
            } elseif ($deporte === 'Basquetbol' && $partido instanceof PartidoBasquetbol) {
                $ganador = $partido->darEquipoGanador();
                if (!in_array($ganador, $ganadores)) {
                    $ganadores[] = $ganador;
                }
            }
        }

        return $ganadores;
    }

    public function calcularPremioPartido($OBJPartido) {
        $equipoGanador = $OBJPartido->darEquipoGanador();
        $coeficiente = $OBJPartido->coeficientePartido();
        $premioPartido = $coeficiente * $this->importePremio;

        return [
            'equipoGanador' => $equipoGanador,
            'premioPartido' => $premioPartido
        ];
    }
}






























// // Ejemplo de uso:
// function main() {
//     $torneo = new Torneo(1000); // Importe del premio base

//     $partidoFutbol = new PartidoFutbol(3, 11, 'Mayores');
//     $partidoBasquetbol = new PartidoBasquetbol(85, 5, 10);

//     $torneo->agregarPartido($partidoFutbol);
//     $torneo->agregarPartido($partidoBasquetbol);

//     $torneo->entregarPremios();
// }

// main();

